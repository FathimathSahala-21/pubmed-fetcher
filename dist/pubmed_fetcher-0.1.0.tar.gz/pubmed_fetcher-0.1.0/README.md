# PubMed Fetcher CLI Tool

This Python script allows you to fetch research papers from PubMed based on a query and identify papers with authors affiliated with pharmaceutical or biotech companies.

## 📦 Requirements

- Python 3.7+
- requests

Install dependencies:
```
pip install -r requirements.txt
```

## 🚀 Usage

```
python pubmed_fetcher.py "cancer immunotherapy" --file results.csv --debug
```

## 🔧 Options

- `--file` to save results to a CSV file
- `--debug` to print debug logs

## 🧠 Notes

Non-academic authors are identified using heuristic rules based on affiliation keywords (e.g., `pharma`, `biotech`, `inc`).